﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Online_Shop.Services;
using Online_Shop.Enums;
using Online_Shop.DataModels;

namespace Online_Shop
{
    public class Application
    {
        CategoryService categoryService = new CategoryService();
        CategoryModel categoryModel = new CategoryModel();
        ItemService itemService = new ItemService();
        ItemModel itemModel = new ItemModel();
        public void InputManage()
        {
            switch (ConsoleHelper.ReadMenu())
            {
                case (byte)ServiceList.AddCategory:
                    CategoryModel category = ConsoleHelper.ReadCategory();
                    categoryService.AddCategoryList(category);
                    ConsoleHelper.Messageshow();
                    break;
                case (byte)ServiceList.AddItem:
                    string item= ConsoleHelper.ReadItem();
                    Dictionary<string, object> obj = ConsoleHelper.ReadAttriubte();
                    categoryService.AddCategoryItem(categoryModel, item);
                    itemService.AddItemAttribute(itemModel, obj.Keys.ToString(),obj.Values);
                    ConsoleHelper.Messageshow();
                    break;
                case (byte)ServiceList.ReportItems:
                    ReadReportHandle();
                    break;
                case 4:
                    ConsoleHelper.Print(categoryService.GetAllCategoryInfo());
                    break;
                case 5:
                    Environment.Exit(0);
                    break;
            }
        }
        public void ReadReportHandle()
        {
            if (categoryService.GetAllCategoryInfo().Count != 0)
            {
                string input = ConsoleHelper.ReadReport();
                foreach (var category in categoryService.GetAllCategoryInfo())
                {
                    if (category.Name == input)
                    {
                        foreach (var item in category.Items)
                        {
                            Console.WriteLine(item);
                        }
                    }
                }
            }
            else
            {
                Console.WriteLine("Caterogy List Is Empty (Please Enter A Category)");
            }
        }
    }
}
