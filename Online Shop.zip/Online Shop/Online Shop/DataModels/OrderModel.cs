﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Shop.DataModels
{
    class OrderModel
    {

        public byte Cost
        {
            get;
            set;
        }
        public byte TotalCost
        {
            get;
            set;
        }
        public double Discount
        {
            get;
            set;
        }
        public DateTime OrderDate
        {
            get;
            set;
        }
        
    }
}
