﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Shop.DataModels
{
     public class CategoryModel
    {
        private static List<string> _Items = new List<string>();
        public string Name
        {
            get;
            set;
        }
        public List<String> Items
        {
            get
            {
                return _Items;
            }
            set
            {
                _Items = value;
            }
        }
      
    }
}
