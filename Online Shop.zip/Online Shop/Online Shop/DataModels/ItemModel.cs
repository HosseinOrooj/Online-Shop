﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Online_Shop.DataModels
{
    public class ItemModel
    {
        private static Dictionary<string, object> Item_Attributes = new Dictionary<string, object>();

        public Dictionary<string, object> ItemAttributes
        {
            get
            {
                return Item_Attributes;
            }
            set
            {
                Item_Attributes = value;
            }
        }

        public string Name
        {
            get;
            set;
        }
        public double Price
        {
            get;
            set;
        }
        public byte Quantity
        {
            get;
            set;
        }
        public double Discount
        {
            get;
            set;
        }
        public string Description
        {
            get;
            set;
        }
        public string Comment
        {
            get;
            set;
        }
    
    }
}
