﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Online_Shop.Services;
using Online_Shop.DataModels;
using Online_Shop.Enums;

namespace Online_Shop
{
    class Program
    {
        static void Main(string[] args)
        {
            
            while (true)
            {
                ConsoleHelper.RunCommand();
            }
            
        }
    }
}
