﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Online_Shop.DataModels;

namespace Online_Shop.Services
{
    public static class ConsoleHelper
    {
        public static byte ReadMenu()
        {
            Console.WriteLine("1.Add A Category");
            Console.WriteLine("2.Add An Item");
            Console.WriteLine("3.Report Items");
            Console.WriteLine("4.Report Catergories And Items");
            Console.WriteLine("5.Exit");
            Console.Write("Enter A Number:");
            byte input = byte.Parse(Console.ReadLine());
            return input;
        }
        public static CategoryModel ReadCategory()
        {
            CategoryModel categoryModel = new CategoryModel();
            Console.Write("Enter A Category Name:");
            categoryModel.Name = Console.ReadLine();
            return categoryModel;
        }
        public static string ReadItem()
        {
            CategoryService categoryService = new CategoryService();
            ConsoleHelper.PrintCategory(categoryService.GetAllCategoryInfo());
            Console.Write("Select A Category:");
            string category = Console.ReadLine();
            Console.Write("Enter An Item:");
            string item = Console.ReadLine();
            foreach (var categories in categoryService.GetAllCategoryInfo())
            {
                if (categories.Name == category)
                {
                    return item;
                }
               
            }
            Console.WriteLine("Invalid Entry");
            return "Invalid Entry";
        }
        public static Dictionary<string,object> ReadAttriubte()
        {
            Dictionary<string, object> dictionary = new Dictionary<string, object>();
            Console.WriteLine("Attributes Menu :");
            Console.Write("Enter Key:");
            string key = Console.ReadLine();
            Console.Write("Enter Value:");
            string value = Console.ReadLine();
            dictionary.Add(key,value);
            return dictionary;
        }
        public static string ReadReport()
        {
            CategoryService categoryService = new CategoryService();
            ItemService itemService = new ItemService();
            CategoryModel categoryModel=new CategoryModel();
            ConsoleHelper.PrintCategory(categoryService.GetAllCategoryInfo());
            Console.Write("Select A Category To Print:");
            string input = Console.ReadLine();
            return input;
        }
        public static void RunCommand()
        {
            Application application = new Application();
            CategoryModel categoryModel = new CategoryModel();
            ItemModel itemModel = new ItemModel();
            application.InputManage();

        }
        public static void Print(List<CategoryModel> list)
        {
            try
            {
                for (int i = 0; i < list.Count; i++)
                {
                    Console.Write("Category Name:" + list[i].Name + "\t Item Name:" + list[i].Items[i] + "\n");
                }
            }
            catch
            {
                Console.WriteLine("Operation Failed ");
            }
        }
        public static void PrintCategory(List<CategoryModel> list)
        {
            foreach (var item in list)
            {
                Console.WriteLine(item.Name);
            }
        }
        public static void Messageshow()
        {
            Console.WriteLine("Successfully Added");
        }
      
       
    }
}
