﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Online_Shop.DataModels;

namespace Online_Shop.Services
{
    class ItemService
    {
        private static List<ItemModel> itemList = new List<ItemModel>();
        public void AddItemList(ItemModel item)
        {
            itemList.Add(item);
        }
        public ItemModel AddItemAttribute(ItemModel item,string key,object value)
        {
            try
            {
                item.ItemAttributes.Add(key, value);
                return item;
            }
            catch
            {
                Console.WriteLine("Adding Failed");
                return item;
            }
            
        }
        public Dictionary<string,object> GetAllAttributes()
        {
            ItemModel itemModel = new ItemModel();
            return itemModel.ItemAttributes;
        }
        public List<ItemModel> GetAllItemInfo()
        {
            return itemList;
        }
       
    }
}
