﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Online_Shop.DataModels;
namespace Online_Shop.Services
{
    class CategoryService
    {
        private static List<CategoryModel> categoryList = new List<CategoryModel>();
        private static List<string> categoryItems = new List<string>();
        public void AddCategoryList(CategoryModel category)
        {
            categoryList.Add(category);
            
        }
        public void AddCategoryItem(CategoryModel category, string input)
        {
            category.Items.Add(input);

        }
        public List<string> GetAllCateroryItems(CategoryModel category)
        {
            return category.Items;
        }
        public List<CategoryModel> GetAllCategoryInfo()
        {
            return categoryList;
        }
    }
}
